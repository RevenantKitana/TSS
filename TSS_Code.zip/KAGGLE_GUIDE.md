# 📖 Hướng Dẫn Chạy Toàn Bộ Mã Nguồn TSS Trên Kaggle (GPU Free Tier)

Kaggle cung cấp **GPU miễn phí lên tới 30 giờ/tuần** (sử dụng GPU NVIDIA **T4 x2** 16GB hoặc **P100** 16GB VRAM, thời gian mỗi session tối đa lên tới 12 giờ liên tục).

Bản notebook [`ZeroTTS_Kaggle_FreeTier.ipynb`](file:///e:/Tools/TSS-main/ZeroTTS_Kaggle_FreeTier.ipynb) đã được tối ưu hóa 100% để chạy trên nền tảng [Kaggle Notebooks](https://www.kaggle.com/code).

---

## ⚡ 2 Thiết Lập Quan Trọng Nhất Trên Kaggle

Trước khi bấm chạy notebook, bạn nhìn sang cột **Notebook settings** (ở cạnh bên phải màn hình Kaggle):

1. **Accelerator**: Chọn **GPU T4 x2** (hoặc **GPU P100**).
2. **Internet**: Chuyển công tắc **Internet** sang **ON** *(Bắt buộc bật để tải mô hình weights từ Hugging Face và tạo đường hầm Cloudflare Tunnel)*.

> 🔴 **Nếu bạn gặp lỗi: `Error: Permission 'kernelSessions.enableInternet' was denied`**  
> 👉 **Nguyên nhân**: Tài khoản Kaggle cần **Xác minh số điện thoại (Phone Verification)** 1 lần duy nhất để Kaggle mở quyền truy cập Internet và cấp 30h GPU/tuần miễn phí (chống bot).  
> 👉 **Cách sửa cực nhanh (1 phút)**:
> 1. Mở trang cài đặt: [https://www.kaggle.com/settings](https://www.kaggle.com/settings)
> 2. Cuộn xuống mục **Phone Verification** -> Nhập số điện thoại của bạn (chọn cờ Việt Nam `+84`, bỏ số 0 ở đầu).
> 3. Nhập mã OTP 6 số gửi về SMS để xác nhận.
> 4. Quay lại Notebook, F5 tải lại trang và gạt **Internet sang ON** là thành công ngay!

---

## 📦 Bước 1: Đóng Gói Mã Nguồn Tùy Chỉnh

1. Tại thư mục dự án trên máy tính, nhấp đúp vào file:
   👉 [`tao_file_zip_colab.bat`](file:///e:/Tools/TSS-main/tao_file_zip_colab.bat)
2. File **`TSS_Code.zip`** sẽ được tạo tự động (~7.5 MB).

---

## 🚀 Bước 2: Tải Lên & Khởi Chạy Trên Kaggle

### Cách 1: Tải file Notebook lên Kaggle (Dễ nhất)
1. Truy cập [Kaggle Notebooks](https://www.kaggle.com/code) -> Bấm nút **New Notebook**.
2. Trên thanh menu trên cùng của Notebook, chọn **File** -> **Upload Notebook** -> Chọn file [`ZeroTTS_Kaggle_FreeTier.ipynb`](file:///e:/Tools/TSS-main/ZeroTTS_Kaggle_FreeTier.ipynb) từ máy bạn.
3. Ở cột bên phải (**Settings**):
   - **Accelerator**: Chọn **GPU T4 x2**
   - **Internet**: Gạt sang **ON**
4. Nạp mã nguồn `TSS_Code.zip`:
   - Bấm **+ Add Data** (góc trên bên phải) -> Chọn **Upload Dataset** -> Đặt tên dataset (ví dụ: `tss-code`) và tải file `TSS_Code.zip` lên.
   - Hoặc bạn có thể sử dụng chế độ **Git Clone** từ Repo GitHub cá nhân / Direct Link ngay trong cell Bước 2 của Notebook.
5. Chọn menu **Run** -> **Run All (Chạy tất cả)**:
   - Hệ thống sẽ tự động cài đặt ONNX Runtime GPU (CUDA), tải mô hình và kích hoạt Cloudflare Tunnel.
6. Khi chạy tới **Bước 5**, bấm vào đường link **Public URL** (`https://xxxx.trycloudflare.com`) để mở WebUI Studio!

---

## 💾 Bước 3: Tải Toàn Bộ File Audio Đã Tạo Về Máy Tính

Trong notebook Kaggle đã có sẵn cell **Bước 7**:
- Cell này tự động gom toàn bộ file `.mp3`, `.wav`, timeline `.json` trong thư mục `outputs/` thành file **`ZeroTTS_Outputs.zip`**.
- Bấm vào link tải trực tiếp trong notebook hoặc vào thẻ **Data / Output** ở thanh bên phải của Kaggle để tải về máy tính.

---

## 🎯 So Sánh Ưu Điểm: Kaggle vs Google Colab

| Tiêu chí | Kaggle Free Tier | Google Colab Free Tier |
| :--- | :--- | :--- |
| **GPU Hỗ Trợ** | **T4 x2 (2 GPU)** hoặc **P100 16GB** | **T4 15GB** |
| **Thời gian session** | Lên tới **12 giờ liên tục** | ~3 - 5 giờ (dễ bị ngắt timeout) |
| **Quota miễn phí** | **30 giờ GPU / tuần** cố định | Linh hoạt theo phân bổ hàng ngày |
| **Giao diện WebUI** | Cloudflare Tunnel HTTPS mượt mà | Cloudflare Tunnel HTTPS mượt mà |
| **Tải kết quả** | Trực tiếp qua tab Output / 1-click zip | Tự động đồng bộ vào Google Drive |

---

## 💻 Khởi Chạy Nhanh Bằng Dòng Lệnh Trên Kaggle

Nếu bạn thích thao tác trực tiếp bằng lệnh trong terminal hoặc Kaggle cell:

```bash
# 1. Cài đặt hệ thống & GPU
apt-get update -qq && apt-get install -y ffmpeg libportaudio2
pip install onnxruntime-gpu soundfile sounddevice fastapi uvicorn tokenizers huggingface_hub scipy requests pydantic
pip install -e .

# 2. Chạy WebUI với Cloudflare Tunnel
python colab_runner.py
```
