# 📖 Hướng Dẫn Chạy ZeroTTS Trên Google Colab Free Tier (Miễn Phí 100%)

Tài liệu này hướng dẫn chi tiết từng bước để bạn có thể chạy **ZeroTTS Studio (TSS WebUI)** hoặc xử lý chuyển văn bản thành giọng nói hàng loạt trên môi trường đám mây **Google Colab Free Tier**, tận dụng GPU T4 mạnh mẽ mà không tốn tài nguyên máy tính cá nhân.

---

## 🚀 Cách 1: Sử dụng File Notebook (`ZeroTTS_Colab_FreeTier.ipynb`) - Khuyên dùng

### Bước 1: Mở Notebook trên Google Colab
1. Truy cập [Google Colab](https://colab.research.google.com).
2. Chọn thẻ **Upload (Tải lên)** -> Chọn file [`ZeroTTS_Colab_FreeTier.ipynb`](file:///e:/Tools/TSS-main/ZeroTTS_Colab_FreeTier.ipynb) từ máy tính của bạn.

### Bước 2: Bật Tăng Tốc Phần Cứng GPU T4 (Miễn phí)
1. Trên thanh menu Colab, chọn **Runtime (Thời gian chạy)** -> **Change runtime type (Thay đổi loại thời gian chạy)**.
2. Tại mục **Hardware accelerator (Bộ tăng tốc phần cứng)**, chọn **T4 GPU**.
3. Nhấn **Save (Lưu)**.

### Bước 3: Chạy Toàn Bộ Các Bước (1-Click Run)
Nhấn **Runtime** -> **Run all (Chạy tất cả)** hoặc bấm chạy tuần tự từng cell:
1. **Cell 1**: Tùy chọn kết nối Google Drive (Mount Drive để lưu vĩnh viễn các file audio xuất ra tại `MyDrive/ZeroTTS_Outputs`).
2. **Cell 2**: Tự động cài đặt thư viện hệ thống (`ffmpeg`, `libportaudio2`) và thư viện tăng tốc `onnxruntime-gpu`.
3. **Cell 3**: Tải trọng số mô hình pre-trained ZeroTTS từ Hugging Face.
4. **Cell 4**: Khởi chạy WebUI và mở đường link **Cloudflare Tunnel** (`https://xxxx.trycloudflare.com`).

### Bước 4: Mở Giao Diện WebUI & Sử Dụng
- Nhấp vào link `https://xxxx.trycloudflare.com` hiển thị ở kết quả của Cell 4.
- Giao diện WebUI Studio sẽ mở ra trên tab mới. Bạn có thể:
  - Nhập văn bản chia theo tag `[Câu 1]`, `#[Bỏ qua]`, `[pause: 1.5s]`, `[Kết Thúc]`.
  - Chọn giọng đọc: Bắc, Nam, Nam/Nữ...
  - Nghe trực tiếp qua trình phát âm thanh streaming.
  - Tải về từng câu riêng lẻ hoặc file đã gộp hoàn chỉnh `_FULL_MERGED.mp3` / `.wav`.

---

## 💻 Cách 2: Chạy Bằng Lệnh Nhanh (Terminal / Python Script)

Nếu bạn muốn khởi chạy trực tiếp qua dòng lệnh trên Colab / máy chủ Linux từ xa:

```bash
# 1. Cài đặt hệ thống & thư viện
apt-get update -qq && apt-get install -y ffmpeg libportaudio2
pip install onnxruntime-gpu soundfile sounddevice fastapi uvicorn tokenizers huggingface_hub scipy requests
pip install -e .

# 2. Khởi chạy WebUI kèm Cloudflare Tunnel tự động
python colab_runner.py
```

Khi chạy xong, terminal sẽ in ra đường link Public HTTPS để bạn truy cập.

---

## ⚡ Ưu Điểm Khi Chạy Trên Colab Free Tier

| Tính năng | Lợi ích |
| :--- | :--- |
| **GPU T4 15GB VRAM** | Tốc độ sinh giọng cực nhanh (Real-Time Factor < 0.1s, 10s audio chỉ mất ~1s render). |
| **Không tốn RAM/CPU máy thật** | Phù hợp cho máy yếu, laptop văn phòng hoặc điện thoại. |
| **Cloudflare Tunnel** | Truy cập từ bất kỳ trình duyệt nào mà không cần cài đặt phần mềm phụ trợ, không cần token. |
| **Tự động lưu Google Drive** | Không lo mất dữ liệu khi ngắt kết nối session Colab. |
