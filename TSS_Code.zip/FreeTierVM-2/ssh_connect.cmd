@echo off
chcp 65001 > nul
title SSH Oracle VM (140.245.124.221)
cd /d "%~dp0"

echo ===================================================
echo     Ket noi SSH toi Oracle VM (140.245.124.221)
echo ===================================================
echo.

ssh -i "%~dp0ssh-key.key" -o StrictHostKeyChecking=no ubuntu@140.245.124.221

echo.
echo Da ngat ket noi SSH.
pause
