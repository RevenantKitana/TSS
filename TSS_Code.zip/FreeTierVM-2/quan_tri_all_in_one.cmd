@echo off
title ZeroTTS All-In-One Toolkit (140.245.124.221)
cd /d "%~dp0"

echo ===============================================================================
echo        KET NOI TOI ZEROTTS ALL-IN-ONE TOOLKIT (BASH SSH)
echo ===============================================================================
echo  * Host: ubuntu@140.245.124.221
echo  * Key : %~dp0ssh-key.key
echo ===============================================================================
echo.

ssh -t -i "%~dp0ssh-key.key" -o StrictHostKeyChecking=no ubuntu@140.245.124.221 "/home/ubuntu/TSS/zerotts.sh"

echo.
echo Da dong phien lam viec.
pause
